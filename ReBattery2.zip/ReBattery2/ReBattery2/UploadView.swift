import SwiftUI
import CoreML
import CoreLocation
import Vision

struct UploadView: View {
    let model: reBattery7
    @Binding var recycledItemsCount: Int // Binding to update the counter in DashboardView
    @Binding var phoneAchieved: Bool
    @Binding var forkKnifeAchieved: Bool
    @Binding var laptopAchieved: Bool
    
    @Binding var phoneGalleryCount: Int
    @Binding var forkGalleryCount: Int
    @Binding var laptopGalleryCount: Int
    
    @State private var classificationLabel: String = ""
    @State private var selectedImage: UIImage?
    @State private var showingImagePicker: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var showingActionSheet: Bool = false
    @State private var currentLocation: CLLocation?
    @State private var locationString: String = "Location not found"
    
    // Location manager
    private let locationManager = CLLocationManager()
    
    init(recycledItemsCount: Binding<Int>,
         phoneAchieved: Binding<Bool>,
         forkKnifeAchieved: Binding<Bool>,
         laptopAchieved: Binding<Bool>,
         phoneGalleryCount: Binding<Int>,
         forkGalleryCount: Binding<Int>,
         laptopGalleryCount: Binding<Int>) {
        
        self._recycledItemsCount = recycledItemsCount
        self._phoneAchieved = phoneAchieved
        self._forkKnifeAchieved = forkKnifeAchieved
        self._laptopAchieved = laptopAchieved
        self._phoneGalleryCount = phoneGalleryCount
        self._forkGalleryCount = forkGalleryCount
        self._laptopGalleryCount = laptopGalleryCount
        
        do {
            model = try reBattery7()
        } catch {
            fatalError("Failed to load reBattery7: \(error)")
        }
    }
    
    var body: some View {
        VStack(spacing: 40) {
            Text("UPLOAD THE PICTURE")
                .font(.custom("Phosphate", size: 24))
                .foregroundColor(Color(hex: "#61BFAD"))
            
            if let selectedImage = selectedImage {
                Image(uiImage: selectedImage)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)
            } else {
                Image(systemName: "viewfinder")
                    .font(.system(size: 120))
                    .foregroundColor(Color(hex: "#61BFAD"))
            }
            
            Button(action: {
                showingActionSheet = true
            }) {
                Text("Upload Image")
                    .font(.custom("Phosphate", size: 16))
                    .foregroundColor(.white)
                    .padding()
                    .background(Color(hex: "#61BFAD"))
                    .cornerRadius(8)
            }
            
            Button("Classify") {
                classifyImage()
            }
            .padding()
            .foregroundColor(.white)
            .background(Color.green)
            .cornerRadius(8)
            
            Text(classificationLabel)
                .padding()
                .font(.headline)
            
            Text(locationString)
                .padding()
                .font(.subheadline)
            
            Spacer()
        }
        .padding()
        .onAppear {
            setupLocationManager()  // Ensure location manager setup when the view appears
        }
        .actionSheet(isPresented: $showingActionSheet) {
            ActionSheet(title: Text("Choose Image Source"), buttons: [
                .default(Text("Camera")) {
                    sourceType = .camera
                    showingImagePicker = true
                },
                .default(Text("Photo Library")) {
                    sourceType = .photoLibrary
                    showingImagePicker = true
                },
                .cancel()
            ])
        }
        .sheet(isPresented: $showingImagePicker) {
            ImagePicker(image: $selectedImage, sourceType: sourceType)
        }
    }
    
    private func classifyImage() {
        guard let image = selectedImage,
              let resizedImage = image.resizeImageTo(size: CGSize(width: 224, height: 224)),
              let buffer = resizedImage.convertToBuffer() else {
            classificationLabel = "Failed to process image."
            return
        }

        do {
            let prediction = try model.prediction(image: buffer)
            if let bestResult = prediction.targetProbability.max(by: { $0.value < $1.value }) {
                classificationLabel = "Classified as: \(bestResult.key)"
                
                // Increment counter if classified as battery
                if bestResult.key == "battery" {
                    recycledItemsCount += 1
                    phoneGalleryCount += 1  // Example logic for gallery count
                    phoneAchieved = true  // Example logic for achievement
                }
            } else {
                classificationLabel = "No result found."
            }
        } catch {
            print("Error making prediction: \(error)")
            classificationLabel = "Error making prediction."
        }
    }
    
    private func setupLocationManager() {
        locationManager.delegate = LocationDelegate { location in
            self.currentLocation = location
            if let latitude = location?.coordinate.latitude,
               let longitude = location?.coordinate.longitude {
                self.locationString = "Lat: \(latitude), Lon: \(longitude)"
            } else {
                self.locationString = "Unable to find location."
            }
        }
        
        locationManager.requestWhenInUseAuthorization()
        
        // Ensure location manager starts updating after permissions are granted
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        } else {
            self.locationString = "Location services are disabled."
        }
    }
}

class LocationDelegate: NSObject, CLLocationManagerDelegate {
    private let locationHandler: (CLLocation?) -> Void

    init(locationHandler: @escaping (CLLocation?) -> Void) {
        self.locationHandler = locationHandler
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else {
            locationHandler(nil)
            return
        }
        locationHandler(location)
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Failed to find user's location: \(error)")
        locationHandler(nil)
    }
}

