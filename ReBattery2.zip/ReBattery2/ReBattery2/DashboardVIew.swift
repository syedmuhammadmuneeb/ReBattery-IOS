import SwiftUI

struct DashboardView: View {
    @State private var recycledItemsCount: Int = 0 // Initial count
    @State private var phoneAchieved: Bool = false
    @State private var forkKnifeAchieved: Bool = false
    @State private var laptopAchieved: Bool = false
    
    @State private var phoneGalleryCount: Int = 0
    @State private var forkGalleryCount: Int = 0
    @State private var laptopGalleryCount: Int = 0

    var body: some View {
        VStack {
            Text("ReBattery")
                .font(.custom("Phosphate", size: 36))
                .foregroundColor(.white)
                .padding()
                .background(Color(hex: "#61BFAD"))

            Spacer()

            Text("My Points")
                .font(.custom("Phosphate", size: 24))
                .padding()

            Text("10")
                .font(.custom("Phosphate", size: 48))
                .bold()

            Text("Items Recycled")
                .font(.custom("Phosphate", size: 24))
                .padding()

            Text("\(recycledItemsCount)") // Display the counter
                .font(.custom("Phosphate", size: 48))
                .bold()

            Spacer()

            Button(action: {
                // Action for recycling batteries
            }) {
                Text("Earn Points by Recycling Batteries")
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()

            // Pass the necessary bindings to UploadView
            NavigationLink(destination: UploadView(
                recycledItemsCount: $recycledItemsCount,
                phoneAchieved: $phoneAchieved,
                forkKnifeAchieved: $forkKnifeAchieved,
                laptopAchieved: $laptopAchieved,
                phoneGalleryCount: $phoneGalleryCount,
                forkGalleryCount: $forkGalleryCount,
                laptopGalleryCount: $laptopGalleryCount
            )) {
                Text("Get started")
                    .padding()
                    .foregroundColor(.blue)
            }

            Spacer()
        }
    }
}

