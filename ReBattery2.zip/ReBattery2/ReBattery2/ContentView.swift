import SwiftUI

struct ContentView: View {
    @State private var points: Int = 10  // Example points value
    @State private var recycledItemsCount: Int = 0  // Track total items recycled
    
    // Declare necessary state variables
    @State private var phoneAchieved: Bool = false
    @State private var forkKnifeAchieved: Bool = false
    @State private var laptopAchieved: Bool = false
    
    @State private var phoneGalleryCount: Int = 0
    @State private var forkGalleryCount: Int = 0
    @State private var laptopGalleryCount: Int = 0
    
    var body: some View {
        NavigationView {
            TabView {
                // Pass both points and recycledItemsCount as bindings to HomeView
                HomeView(points: $points, recycledItemsCount: $recycledItemsCount)
                    .tabItem {
                        Image(systemName: "square")
                        Text("Dashboard")
                    }
                
                GoalsView()
                    .tabItem {
                        Image(systemName: "map")
                        Text("Map")
                    }
                
                // Pass the recycledItemsCount to UploadView as well
                UploadView(
                    recycledItemsCount: $recycledItemsCount,
                    phoneAchieved: $phoneAchieved,
                    forkKnifeAchieved: $forkKnifeAchieved,
                    laptopAchieved: $laptopAchieved,
                    phoneGalleryCount: $phoneGalleryCount,
                    forkGalleryCount: $forkGalleryCount,
                    laptopGalleryCount: $laptopGalleryCount
                )
                .tabItem {
                    Image(systemName: "camera.fill")
                    Text("Upload")
                }
                
                // Pass both points and recycledItemsCount to MyCollectionsView
                MyCollectionsView(
                    points: $points,
                    totalItemsRecycled: $recycledItemsCount
                )
                .tabItem {
                    Image(systemName: "info.circle")
                    Text("My Collections")
                }
            }
            .accentColor(Color(hexCode: "#61BFAD"))
            .navigationBarTitleDisplayMode(.inline)  // Inline title
            .navigationTitle("ReBattery")  // Set the header for the content screen
            .onAppear {
                // Customize the navigation bar color theme here
                let appearance = UINavigationBarAppearance()
                appearance.configureWithOpaqueBackground()
                appearance.backgroundColor = UIColor(Color(hexCode: "#61BFAD"))  // Set the background color
                appearance.titleTextAttributes = [.foregroundColor: UIColor.white]  // Title color
                appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]  // Large title color
                UINavigationBar.appearance().standardAppearance = appearance
                UINavigationBar.appearance().compactAppearance = appearance
                UINavigationBar.appearance().scrollEdgeAppearance = appearance
            }
        }
    }
}

