import SwiftUI

struct HomeView: View {
    @Binding var points: Int  // Accept points as a binding
    @Binding var recycledItemsCount: Int  // Accept recycled items count as a binding
    @State private var showPopover = false  // State to control popover visibility
    
    var body: some View {
        VStack(spacing: 20) {
            Spacer()  // To push content to the center of the screen

            Text("My Points")
                .font(.custom("Phosphate", size: 24))
                .foregroundColor(Color(hexCode: "#61BFAD"))
            
            Text("\(points)")
                .font(.custom("Phosphate", size: 48))  // Inline font for number
                .foregroundColor(Color(hexCode: "#61BFAD"))
                .bold()  // Making the points bold
            
            Text("Items Recycled")
                .font(.custom("Phosphate", size: 24))
                .foregroundColor(Color(hexCode: "#61BFAD"))
            
            Text("\(recycledItemsCount)")  // Display the dynamic count
                .font(.custom("Phosphate", size: 48))  // Inline font for number
                .foregroundColor(Color(hexCode: "#61BFAD"))
                .bold()  // Making the items recycled count bold
            
            Spacer()  // Add space between sections

            // "Earn Points" button
            Button(action: {
                recycledItemsCount += 1  // Increment recycled items count
                showPopover.toggle()  // Toggle popover visibility when clicked
            }) {
                VStack {
                    Text("Earn Points by Recycling Batteries")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)  // Text color adapts to system mode
                    
                    Text("Get started →")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(Color(hexCode: "#61BFAD"))  // Set arrow color to #61BFAD
                }
            }
            .padding()
            .background(RoundedRectangle(cornerRadius: 8).stroke(Color(hexCode: "#61BFAD"), lineWidth: 1))  // Set border color to #61BFAD
            .background(Color(.systemBackground))  // Ensure the background adapts to system mode
            .cornerRadius(8)
            .popover(isPresented: $showPopover) {
                VStack(alignment: .leading, spacing: 15) {
                    Text("Rules for Earning Points")
                        .font(.custom("Phosphate", size: 24))
                        .foregroundColor(Color(hexCode: "#61BFAD"))
                    
                    Text("1. Once your milestone is achieved, you get points.")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)  // Responsive text color
                    
                    Text("2. The points are as under:")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)  // Responsive text color
                    
                    Text("   - 1 Mobile phone created: 5 points")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)  // Responsive text color
                    
                    Text("   - 1 Fork/Knife created: 3 points")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)  // Responsive text color
                    
                    Text("   - 1 Laptop created: 15 points")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)  // Responsive text color
                    
                    Button(action: {
                        showPopover = false  // Close popover when button clicked
                    }) {
                        Text("Close")
                            .font(.custom("Phosphate", size: 16))
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
                    }
                    .padding(.top, 20)
                }
                .padding()
                .frame(width: 300, height: 350)  // Set a fixed size for the popover content
            }
        }
        .padding()
    }
}

