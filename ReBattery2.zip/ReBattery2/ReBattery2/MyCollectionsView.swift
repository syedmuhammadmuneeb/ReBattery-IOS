import SwiftUI

struct MyCollectionsView: View {
    @Binding var points: Int  // Binding for points
    @Binding var totalItemsRecycled: Int  // Binding for total items recycled
    
    @State private var phoneAchieved: Int = 0
    @State private var forkKnifeAchieved: Int = 0
    @State private var laptopAchieved: Int = 0
    
    @State private var collectedItems: [String] = []  // To store the collected items for display
    @State private var itemCounts: [String: Int] = ["iphone": 0, "fork.knife": 0, "laptopcomputer": 0] // Store counts of each item in the gallery
    
    let items = [
        ("Laptop", "laptopcomputer", 10),
        ("Fork/Knife", "fork.knife", 7),
        ("Phone", "iphone", 5)
    ]
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Title: "MY COLLECTIONS" with background color
                Text("MY COLLECTIONS")
                    .font(.custom("Phosphate", size: 24))
                    .bold()
                    .foregroundColor(.white) // White text
                    .frame(maxWidth: .infinity) // Full width
                    .padding()
                    .background(Color(hexCode: "#61BFAD")) // Background color
                    .cornerRadius(8) // Rounded corners
                    .shadow(radius: 5) // Shadow for better look
                
                // Display points section with a highlight color
                Text("Your points are currently: \(points)")
                    .font(.custom("Phosphate", size: 16))
                    .foregroundColor(Color(hexCode: "#61BFAD"))
                
                // Display total items recycled
                Text("Your total items recycled are: \(totalItemsRecycled)")
                    .font(.custom("Phosphate", size: 16))
                    .foregroundColor(Color(hexCode: "#61BFAD"))
                
                // Milestones Achieved Section
                VStack(spacing: 20) {
                    Text("Milestones Achieved")
                        .font(.custom("Phosphate", size: 20))
                        .foregroundColor(Color(hexCode: "#61BFAD"))
                    
                    // Phone Milestone Progress Bar
                    HStack {
                        Image(systemName: "iphone")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        ProgressBar(progress: $phoneAchieved, maxValue: 5)
                            .frame(width: 200, height: 30)
                        
                        // Milestone number with border and text in background theme
                        Text("\(phoneAchieved)/5")
                            .font(.custom("Phosphate", size: 16))
                            .foregroundColor(.black)
                            .padding(5)
                            .background(Color.white)  // White background for the number
                            .cornerRadius(5)
                            .border(Color.white, width: 2)  // White border around the number
                    }
                    
                    // Fork/Knife Milestone Progress Bar
                    HStack {
                        Image(systemName: "fork.knife")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        ProgressBar(progress: $forkKnifeAchieved, maxValue: 7)
                            .frame(width: 200, height: 30)
                        
                        // Milestone number with border and text in background theme
                        Text("\(forkKnifeAchieved)/7")
                            .font(.custom("Phosphate", size: 16))
                            .foregroundColor(.black)
                            .padding(5)
                            .background(Color.white)  // White background for the number
                            .cornerRadius(5)
                            .border(Color.white, width: 2)  // White border around the number
                    }
                    
                    // Laptop Milestone Progress Bar
                    HStack {
                        Image(systemName: "laptopcomputer")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        ProgressBar(progress: $laptopAchieved, maxValue: 10)
                            .frame(width: 200, height: 30)
                        
                        // Milestone number with border and text in background theme
                        Text("\(laptopAchieved)/10")
                            .font(.custom("Phosphate", size: 16))
                            .foregroundColor(.black)
                            .padding(5)
                            .background(Color.white)  // White background for the number
                            .cornerRadius(5)
                            .border(Color.white, width: 2)  // White border around the number
                    }
                }
                .padding(.top)
                
                // Items in Your Collection Section
                Text("Items in Your Collection")
                    .font(.custom("Phosphate", size: 20))
                    .foregroundColor(Color(hexCode: "#61BFAD"))
                
                // Horizontal scrollable layout for items in the collection with small icons
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(itemCounts.keys.sorted(), id: \.self) { key in
                            VStack {
                                // Display the icon for each item type, smaller size
                                Image(systemName: key)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30, height: 30)  // Smaller icon size
                                    .foregroundColor(Color(hexCode: "#61BFAD"))
                                
                                // Display the count of each item in the gallery
                                Text("\(itemCounts[key] ?? 0)")
                                    .font(.custom("Phosphate", size: 16))
                                    .foregroundColor(Color(hexCode: "#61BFAD"))
                            }
                            .padding()
                        }
                    }
                }
                .padding(.top)
                
                // My Collections Gallery Section
                Text("My Collections Gallery")
                    .font(.custom("Phosphate", size: 20))
                    .foregroundColor(Color(hexCode: "#61BFAD"))
                
                // Grid layout for achievements with icons
                LazyVGrid(columns: [
                    GridItem(.flexible()),
                    GridItem(.flexible())
                ], spacing: 20) {
                    ForEach(collectedItems, id: \.self) { item in
                        VStack {
                            Image(systemName: item)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                                .foregroundColor(Color(hexCode: "#61BFAD"))
                            
                            Text(itemName(for: item))
                                .font(.custom("Phosphate", size: 16))
                                .foregroundColor(Color(hexCode: "#61BFAD"))
                        }
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
                    }
                }
                .padding(.top)
            }
            .padding()
            .onChange(of: totalItemsRecycled) { _ in
                // Check and update the milestone progress for each item
                updateMilestones()
            }
        }
    }
    
    // Function to update progress based on the total items recycled
    private func updateMilestones() {
        // Handle phone milestone
        if phoneAchieved < 5 && totalItemsRecycled > 0 {
            phoneAchieved += 1
        }
        if phoneAchieved == 5 {
            // Add phone to the collection and award points
            itemCounts["iphone"] = (itemCounts["iphone"] ?? 0) + 1  // Increment phone count
            collectedItems.append("iphone") // Add phone to collection
            points += 5
            phoneAchieved = 0  // Reset phone achievement after milestone
        }
        
        // Handle fork/knife milestone
        if forkKnifeAchieved < 7 && totalItemsRecycled > 0 {
            forkKnifeAchieved += 1
        }
        if forkKnifeAchieved == 7 {
            // Add fork/knife to the collection and award points
            itemCounts["fork.knife"] = (itemCounts["fork.knife"] ?? 0) + 1  // Increment fork/knife count
            collectedItems.append("fork.knife") // Add fork/knife to collection
            points += 7
            forkKnifeAchieved = 0  // Reset fork/knife achievement after milestone
        }
        
        // Handle laptop milestone
        if laptopAchieved < 10 && totalItemsRecycled > 0 {
            laptopAchieved += 1
        }
        if laptopAchieved == 10 {
            // Add laptop to the collection and award points
            itemCounts["laptopcomputer"] = (itemCounts["laptopcomputer"] ?? 0) + 1  // Increment laptop count
            collectedItems.append("laptopcomputer") // Add laptop to collection
            points += 10
            laptopAchieved = 0  // Reset laptop achievement after milestone
        }
    }
    
    // Function to get the correct display name for items
    private func itemName(for item: String) -> String {
        switch item {
        case "iphone":
            return "iPhone"
        case "fork.knife":
            return "Fork & Knife"
        case "laptopcomputer":
            return "Laptop"
        default:
            return item
        }
    }
}

struct ProgressBar: View {
    @Binding var progress: Int
    var maxValue: Int
    
    var body: some View {
        ZStack {
            // Background of the progress bar (battery shape)
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.gray.opacity(0.2))
            
            // Foreground of the progress bar (filled part)
            RoundedRectangle(cornerRadius: 10)
                .fill(progress == maxValue ? Color.green : Color(hexCode: "#61BFAD"))
                .frame(width: CGFloat(progress) / CGFloat(maxValue) * 200, height: 30)
                .animation(.easeInOut(duration: 0.5), value: progress)
        }
    }
}

