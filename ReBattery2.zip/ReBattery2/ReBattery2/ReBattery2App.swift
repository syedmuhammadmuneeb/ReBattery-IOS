//
//  ReBattery2App.swift
//  ReBattery2
//
//  Created by Muhammad Usman on 05/11/2024.
//

import SwiftUI

@main
struct ReBattery2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
