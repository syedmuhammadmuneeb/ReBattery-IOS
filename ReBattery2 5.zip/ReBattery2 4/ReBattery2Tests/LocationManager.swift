import CoreLocation
import SwiftUI

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private let manager = CLLocationManager()
    @Published var location: CLLocation?  // This will store the user's current location
    @Published var locationString: String = "Location not found"  // Text to show the location as a string

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        requestLocationAccess()
    }
    
    func requestLocationAccess() {
        // Request "when in use" authorization
        manager.requestWhenInUseAuthorization()
        
        // Start updating location if authorization is already granted
        if CLLocationManager.locationServicesEnabled() {
            manager.startUpdatingLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let newLocation = locations.last {
            location = newLocation
            locationString = "Lat: \(newLocation.coordinate.latitude), Lon: \(newLocation.coordinate.longitude)"
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location update failed with error: \(error)")
        locationString = "Unable to find location."
    }
}

