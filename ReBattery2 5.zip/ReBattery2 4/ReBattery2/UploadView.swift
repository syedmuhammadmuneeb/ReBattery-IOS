import SwiftUI
import CoreLocation

struct UploadView: View {
    let model: reBattery7
    let batteryDropOffPoints: [Location] // Drop-off points passed from GoalsView
    @ObservedObject private var locationManager = LocationManager() // Location manager instance

    @Binding var recycledItemsCount: Int
    @Binding var phoneAchieved: Bool
    @Binding var forkKnifeAchieved: Bool
    @Binding var laptopAchieved: Bool
    @Binding var watchAchieved: Bool
    @Binding var screwdriverAchieved: Bool

    @Binding var phoneGalleryCount: Int
    @Binding var forkGalleryCount: Int
    @Binding var laptopGalleryCount: Int
    @Binding var watchGalleryCount: Int
    @Binding var screwdriverGalleryCount: Int

    @State private var classificationLabel: String = ""
    @State private var selectedImage: UIImage?
    @State private var showingImagePicker: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var showingActionSheet: Bool = false
    @State private var showingAlert: Bool = false
    @State private var atValidDropOffPoint: Bool = false // New state for valid location
    @State private var congratulatoryMessage: String = "" // State for congratulatory message

    // Define allowed coordinates
    private let validLocations = [
        CLLocation(latitude: 40.822975, longitude: 14.216369),  // Villa Doria d'Angri
        CLLocation(latitude: 40.81852918203492, longitude: 14.161909067853237) // Another valid location
    ]

    init(recycledItemsCount: Binding<Int>,
         phoneAchieved: Binding<Bool>,
         forkKnifeAchieved: Binding<Bool>,
         laptopAchieved: Binding<Bool>,
         watchAchieved: Binding<Bool>,
         screwdriverAchieved: Binding<Bool>,
         phoneGalleryCount: Binding<Int>,
         forkGalleryCount: Binding<Int>,
         laptopGalleryCount: Binding<Int>,
         watchGalleryCount: Binding<Int>,
         screwdriverGalleryCount: Binding<Int>,
         batteryDropOffPoints: [Location]) {

        self._recycledItemsCount = recycledItemsCount
        self._phoneAchieved = phoneAchieved
        self._forkKnifeAchieved = forkKnifeAchieved
        self._laptopAchieved = laptopAchieved
        self._watchAchieved = watchAchieved
        self._screwdriverAchieved = screwdriverAchieved
        self._phoneGalleryCount = phoneGalleryCount
        self._forkGalleryCount = forkGalleryCount
        self._laptopGalleryCount = laptopGalleryCount
        self._watchGalleryCount = watchGalleryCount
        self._screwdriverGalleryCount = screwdriverGalleryCount
        self.batteryDropOffPoints = batteryDropOffPoints

        do {
            model = try reBattery7()
        } catch {
            fatalError("Failed to load reBattery7: \(error)")
        }
    }

    var body: some View {
        VStack(spacing: 40) {
            Text("UPLOAD THE PICTURE")
                .font(.custom("Phosphate", size: 24))
                .foregroundColor(Color(hex: "#61BFAD"))

            if let selectedImage = selectedImage {
                Image(uiImage: selectedImage)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)
            } else {
                Image(systemName: "viewfinder")
                    .font(.system(size: 120))
                    .foregroundColor(Color(hex: "#61BFAD"))
            }

            Button(action: {
                showingActionSheet = true
            }) {
                Text("Select Image")
                    .font(.custom("Phosphate", size: 16))
                    .foregroundColor(.white)
                    .padding()
                    .background(Color(hex: "#61BFAD"))
                    .cornerRadius(8)
            }
            .actionSheet(isPresented: $showingActionSheet) {
                ActionSheet(title: Text("Choose Image Source"), buttons: [
                    .default(Text("Camera")) {
                        sourceType = .camera
                        showingImagePicker = true
                    },
                    .default(Text("Photo Library")) {
                        sourceType = .photoLibrary
                        showingImagePicker = true
                    },
                    .cancel()
                ])
            }

            Button("Classify") {
                classifyImage()
            }
            .padding()
            .foregroundColor(.white)
            .background(Color.green)
            .cornerRadius(8)

            Text(classificationLabel)
                .padding()
                .font(.headline)

            Spacer()
        }
        .padding()
        .sheet(isPresented: $showingImagePicker) {
            ImagePicker(image: $selectedImage, sourceType: sourceType)
        }
        .alert(isPresented: $showingAlert) {
            Alert(
                title: Text(atValidDropOffPoint ? "Congratulations!" : "Error"),
                message: Text(congratulatoryMessage),
                dismissButton: .default(Text("OK")) {
                    resetView()
                }
            )
        }
    }

    private func classifyImage() {
        // Check if user is at a valid drop-off point
        guard isValidDropOffLocation() else {
            congratulatoryMessage = "You are at the wrong address."
            atValidDropOffPoint = false
            showingAlert = true
            return
        }

        guard let image = selectedImage,
              let resizedImage = image.resizeImageTo(size: CGSize(width: 224, height: 224)),
              let buffer = resizedImage.convertToBuffer() else {
            classificationLabel = "Failed to process image."
            return
        }

        do {
            let prediction = try model.prediction(image: buffer)
            if let bestResult = prediction.targetProbability.max(by: { $0.value < $1.value }) {
                classificationLabel = "Classified as: \(bestResult.key)"

                if bestResult.key == "battery" {
                    recycledItemsCount += 1
                    phoneGalleryCount += 1
                    phoneAchieved = true
                    resetGoalIfAchieved(for: "battery")

                    congratulatoryMessage = "You are at a valid drop-off point. Coordinates: Lat: 40.8194, Lon: 14.1667"
                    atValidDropOffPoint = true
                    showingAlert = true
                }
            } else {
                classificationLabel = "No result found."
            }
        } catch {
            print("Error making prediction: \(error)")
            classificationLabel = "Error making prediction."
        }
    }

    private func isValidDropOffLocation() -> Bool {
        guard let userLocation = locationManager.userLocation else { return false }

        // Check if user location is within acceptable distance of any valid location or battery drop-off point
        let validDropOffs = validLocations + batteryDropOffPoints.map {
            CLLocation(latitude: $0.coordinate.latitude, longitude: $0.coordinate.longitude)
        }
        return validDropOffs.contains { $0.distance(from: userLocation) < 50 } // Distance threshold in meters
    }

    private func resetGoalIfAchieved(for itemType: String) {
        if itemType == "battery" && phoneGalleryCount >= 5 {
            phoneGalleryCount = 0
            phoneAchieved = false
        }
    }

    private func resetView() {
        selectedImage = nil
        classificationLabel = ""
        congratulatoryMessage = ""
        atValidDropOffPoint = false
    }
}

