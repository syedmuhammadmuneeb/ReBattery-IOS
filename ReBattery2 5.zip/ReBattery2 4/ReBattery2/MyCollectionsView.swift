import SwiftUI

struct MyCollectionsView: View {
    @Binding var points: Int  // Binding for points
    @Binding var totalItemsRecycled: Int  // Binding for total items recycled
    
    @State private var phoneAchieved: Int = 0
    @State private var forkKnifeAchieved: Int = 0
    @State private var laptopAchieved: Int = 0
    @State private var watchAchieved: Int = 0
    @State private var screwdriverAchieved: Int = 0
    
    @State private var collectedItems: [String] = []  // To store the collected items for display
    @State private var itemCounts: [String: Int] = [
        "iphone": 0,
        "fork.knife": 0,
        "laptopcomputer": 0,
        "applewatch": 0, // Corrected for watch
        "screwdriver": 0
    ] // Store counts of each item in the gallery
    
    let items = [
        ("Laptop", "laptopcomputer", 10),
        ("Fork/Knife", "fork.knife", 7),
        ("Phone", "iphone", 5),
        ("Watch", "applewatch", 3), // Corrected for watch
        ("Screwdriver", "screwdriver", 4)
    ]
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                
                // Display points section with a slight increase in size
                Text("Your points are currently: \(points)")
                    .font(.custom("Phosphate", size: 18))  // Slightly bigger font
                    .bold()  // Bold text for visibility
                    .foregroundColor(Color(hexCode: "#61BFAD"))
                
                // Display total items recycled with a slight increase in size
                Text("Your total items recycled are: \(totalItemsRecycled)")
                    .font(.custom("Phosphate", size: 18))  // Slightly bigger font
                    .bold()  // Bold text for visibility
                    .foregroundColor(Color(hexCode: "#61BFAD"))
                
                // Milestones Achieved Section (Left-aligned)
                VStack(alignment: .leading, spacing: 20) {
                    Text("Milestones Achieved")
                        .font(.custom("Phosphate", size: 20))
                        .bold()  // Bold text for emphasis
                        .foregroundColor(Color(hexCode: "#61BFAD"))
                    
                    // Phone Milestone Progress Bar
                    HStack {
                        Image(systemName: "iphone")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        ProgressView(value: Double(phoneAchieved), total: 5)
                            .progressViewStyle(LinearProgressViewStyle())
                            .frame(width: 200, height: 30)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        Text("\(phoneAchieved)/5")
                            .font(.custom("Phosphate", size: 16))
                            .bold()  // Bold text for visibility
                            .foregroundColor(.black)
                            .padding(5)
                            .background(Color.white)
                            .cornerRadius(5)
                            .border(Color.white, width: 2)
                    }
                    
                    // Fork/Knife Milestone Progress Bar
                    HStack {
                        Image(systemName: "fork.knife")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        ProgressView(value: Double(forkKnifeAchieved), total: 7)
                            .progressViewStyle(LinearProgressViewStyle())
                            .frame(width: 200, height: 30)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        Text("\(forkKnifeAchieved)/7")
                            .font(.custom("Phosphate", size: 16))
                            .bold()  // Bold text for visibility
                            .foregroundColor(.black)
                            .padding(5)
                            .background(Color.white)
                            .cornerRadius(5)
                            .border(Color.white, width: 2)
                    }
                    
                    // Laptop Milestone Progress Bar
                    HStack {
                        Image(systemName: "laptopcomputer")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        ProgressView(value: Double(laptopAchieved), total: 10)
                            .progressViewStyle(LinearProgressViewStyle())
                            .frame(width: 200, height: 30)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        Text("\(laptopAchieved)/10")
                            .font(.custom("Phosphate", size: 16))
                            .bold()  // Bold text for visibility
                            .foregroundColor(.black)
                            .padding(5)
                            .background(Color.white)
                            .cornerRadius(5)
                            .border(Color.white, width: 2)
                    }
                    
                    // Watch Milestone Progress Bar
                    HStack {
                        Image(systemName: "applewatch") // Correct system name for the watch icon
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        ProgressView(value: Double(watchAchieved), total: 3)
                            .progressViewStyle(LinearProgressViewStyle())
                            .frame(width: 200, height: 30)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        Text("\(watchAchieved)/3")
                            .font(.custom("Phosphate", size: 16))
                            .bold()  // Bold text for visibility
                            .foregroundColor(.black)
                            .padding(5)
                            .background(Color.white)
                            .cornerRadius(5)
                            .border(Color.white, width: 2)
                    }
                    
                    // Screwdriver Milestone Progress Bar
                    HStack {
                        Image(systemName: "wrench")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        ProgressView(value: Double(screwdriverAchieved), total: 4)
                            .progressViewStyle(LinearProgressViewStyle())
                            .frame(width: 200, height: 30)
                            .foregroundColor(Color(hexCode: "#61BFAD"))
                        
                        Text("\(screwdriverAchieved)/4")
                            .font(.custom("Phosphate", size: 16))
                            .bold()  // Bold text for visibility
                            .foregroundColor(.black)
                            .padding(5)
                            .background(Color.white)
                            .cornerRadius(5)
                            .border(Color.white, width: 2)
                    }
                }
                .padding(.top)
                
                // Items in Your Collection Section
                Text("Items in Your Collection")
                    .font(.custom("Phosphate", size: 20))
                    .bold()  // Bold text for emphasis
                    .foregroundColor(Color(hexCode: "#61BFAD"))
                    .padding(.bottom, 10)  // Reduce space between heading and items below

                // Horizontal scrollable layout for items in the collection with small icons
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 14) { // Reduced spacing here
                        ForEach(itemCounts.keys.sorted(), id: \.self) { key in
                            VStack(spacing: 4) {  // Reduced spacing between icon and text
                                Image(systemName: key)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30, height: 30)
                                    .foregroundColor(Color(hexCode: "#61BFAD"))
                                
                                Text("\(itemCounts[key] ?? 0)")
                                    .font(.custom("Phosphate", size: 16))
                                    .bold()  // Bold text for visibility
                                    .foregroundColor(Color(hexCode: "#61BFAD"))
                                    .padding(.top, 2)  // Reduced padding between icon and count
                            }
                            .padding()
                        }
                    }
                }
                .padding(.top, 10)  // Add small top padding to scroll view to avoid too much space

                // My Collections Gallery Section
                Text("My Collections Gallery")
                    .font(.custom("Phosphate", size: 18))
                    .bold()  // Bold text for emphasis
                    .foregroundColor(Color(hexCode: "#61BFAD"))
                    
                // Fixed Grid Layout (5 items per row)
                VStack(spacing: 20) {
                    // Dynamically calculate the number of rows
                    ForEach(0..<((collectedItems.count + 4) / 5), id: \.self) { rowIndex in
                        HStack {
                            ForEach(0..<5) { columnIndex in
                                let index = rowIndex * 5 + columnIndex
                                if index < collectedItems.count {
                                    CollectionItemView(item: collectedItems[index])
                                } else {
                                    Spacer() // Fill any empty space in the grid
                                }
                            }
                        }
                    }
                }
                .padding(.top)
            }
        }
        .padding()
        .onChange(of: totalItemsRecycled) { _ in
            // Check and update the milestone progress for each item
            updateMilestones()
        }
    }
    
    // Function to update progress based on milestones
    func updateMilestones() {
        // Update milestones when total items recycled change
        if phoneAchieved < 5 && totalItemsRecycled > 0 {
            phoneAchieved += 1
        }
        if phoneAchieved == 5 {
            itemCounts["iphone"] = (itemCounts["iphone"] ?? 0) + 1
            collectedItems.append("iphone")
            points += 5
            phoneAchieved = 0
        }
        
        // Handle fork/knife milestone
        if forkKnifeAchieved < 7 && totalItemsRecycled > 0 {
            forkKnifeAchieved += 1
        }
        if forkKnifeAchieved == 7 {
            itemCounts["fork.knife"] = (itemCounts["fork.knife"] ?? 0) + 1
            collectedItems.append("fork.knife")
            points += 7
            forkKnifeAchieved = 0
        }
        
        // Handle laptop milestone
        if laptopAchieved < 10 && totalItemsRecycled > 0 {
            laptopAchieved += 1
        }
        if laptopAchieved == 10 {
            itemCounts["laptopcomputer"] = (itemCounts["laptopcomputer"] ?? 0) + 1
            collectedItems.append("laptopcomputer")
            points += 10
            laptopAchieved = 0
        }
        
        // Handle watch milestone
        if watchAchieved < 3 && totalItemsRecycled > 0 {
            watchAchieved += 1
        }
        if watchAchieved == 3 {
            itemCounts["applewatch"] = (itemCounts["applewatch"] ?? 0) + 1
            collectedItems.append("applewatch")
            points += 3
            watchAchieved = 0
        }
        
        // Handle screwdriver milestone
        if screwdriverAchieved < 4 && totalItemsRecycled > 0 {
            screwdriverAchieved += 1
        }
        if screwdriverAchieved == 4 {
            itemCounts["screwdriver"] = (itemCounts["screwdriver"] ?? 0) + 1
            collectedItems.append("screwdriver")
            points += 4
            screwdriverAchieved = 0
        }
    }
}

// Collection item view that shows only the item icon as a reward
struct CollectionItemView: View {
    var item: String
    
    var body: some View {
        VStack {
            Image(systemName: item)
                .resizable()
                .scaledToFit()
                .frame(width: 30, height: 30)
                .foregroundColor(Color(hexCode: "#61BFAD"))
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 5)
    }
}

