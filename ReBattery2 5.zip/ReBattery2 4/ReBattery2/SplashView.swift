//
//  SplashView.swift
//  ReBattery2
//
//  Created by Muhammad Usman on 11/11/2024.
//

import Foundation
import SwiftUI

struct SplashView: View {
    @State private var isActive = false
    
    var body: some View {
        VStack {
            if isActive {
                // Navigate to your ContentView after the splash screen
                ContentView()
            } else {
                // Splash screen with the logo
                Image("AppLogo")  // Replace with your logo asset name
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)  // Adjust size as needed
                    .onAppear {
                        // Set a delay for the splash screen before moving to ContentView
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                            withAnimation {
                                self.isActive = true
                            }
                        }
                    }
            }
        }
        .transition(.opacity)
    }
}

struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView()
    }
}
