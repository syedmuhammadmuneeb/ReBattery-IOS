import SwiftUI
import MapKit

struct GoalsView: View {
    @StateObject private var locationManager = LocationManager()
    @State private var batteryDropOffPoints: [Location] = []
    @State private var region: MKCoordinateRegion

    // Define Villa Doria d'Angri location
    private let villaDoriaLocation = Location(
        name: "Villa Doria d'Angri",
        coordinate: CLLocationCoordinate2D(latitude: 40.822975, longitude: 14.216369)
    )

    init() {
        // Set initial region centered on Villa Doria d'Angri
        _region = State(initialValue: MKCoordinateRegion(
            center: villaDoriaLocation.coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
        ))
    }

    var body: some View {
        VStack {
            Text("Battery Drop-off Points")
                .font(.custom("Phosphate", size: 32))
                .foregroundColor(Color(hexCode: "#61BFAD"))
                .padding(.top)

            CustomMapView(
                userLocation: locationManager.userLocation,
                villaLocation: villaDoriaLocation,
                batteryDropOffPoints: batteryDropOffPoints,
                region: $region // Passing region as a binding
            )
            .frame(height: 400)
            .onAppear {
                // We don't need to start location manager here as it's already started in LocationManager's init
                searchNearbyBatteryDropOffs()
            }
        }
    }

    // Search for nearby drop-off locations (Farmacia and Tabacchi) around Villa Doria d'Angri
    private func searchNearbyBatteryDropOffs() {
        let queries = ["Farmacia", "Tabacchi"]
        
        for query in queries {
            let request = MKLocalSearch.Request()
            request.naturalLanguageQuery = query
            request.region = MKCoordinateRegion(
                center: villaDoriaLocation.coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05) // Wider search area
            )

            let search = MKLocalSearch(request: request)
            search.start { response, error in
                if let error = error {
                    print("Error searching for \(query): \(error.localizedDescription)")
                    return
                }

                guard let response = response else { return }
                let locations = response.mapItems.prefix(5).map { item in
                    Location(name: "\(query): \(item.name ?? "Unknown")", coordinate: item.placemark.coordinate)
                }

                DispatchQueue.main.async {
                    self.batteryDropOffPoints.append(contentsOf: locations)
                }
            }
        }
    }
}

