import SwiftUI
import MapKit
import CoreLocation

struct CustomMapView: UIViewRepresentable {
    var userLocation: CLLocation?
    var villaLocation: Location
    var batteryDropOffPoints: [Location]
    
    @Binding var region: MKCoordinateRegion // Binding region to manage outside of view updates
    @State private var isFirstLoad = true // Track if it's the first load to avoid resetting view
    
    init(userLocation: CLLocation?, villaLocation: Location, batteryDropOffPoints: [Location], region: Binding<MKCoordinateRegion>) {
        self.userLocation = userLocation
        self.villaLocation = villaLocation
        self.batteryDropOffPoints = batteryDropOffPoints
        _region = region
    }

    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.showsUserLocation = true // Show the default blue dot for user location
        mapView.delegate = context.coordinator
        return mapView
    }

    func updateUIView(_ mapView: MKMapView, context: Context) {
        // Only update the map region if it's the first load and user location is available
        if isFirstLoad, let userLocation = userLocation {
            // Center map to user's location on the first load
            let newRegion = MKCoordinateRegion(
                center: userLocation.coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
            )
            region = newRegion
            mapView.setRegion(newRegion, animated: true) // Set region with animation
            isFirstLoad = false
        }

        // Remove previous annotations (except user location)
        mapView.removeAnnotations(mapView.annotations)

        // Add Villa Doria d'Angri location annotation
        let villaAnnotation = MKPointAnnotation()
        villaAnnotation.coordinate = villaLocation.coordinate
        villaAnnotation.title = villaLocation.name
        mapView.addAnnotation(villaAnnotation)

        // Add annotations for nearby battery drop-off points
        for location in batteryDropOffPoints {
            let annotation = MKPointAnnotation()
            annotation.coordinate = location.coordinate
            annotation.title = location.name
            mapView.addAnnotation(annotation)
        }

        // Add a custom annotation for the user's location with a red pin
        if let userLocation = userLocation {
            let userLocationAnnotation = MKPointAnnotation()
            userLocationAnnotation.coordinate = userLocation.coordinate
            userLocationAnnotation.title = "Your Location"
            mapView.addAnnotation(userLocationAnnotation)
        }
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator()
    }

    class Coordinator: NSObject, MKMapViewDelegate {
        // Customize the view for annotations
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            // Customize the user location with a "person" or "pin" symbol
            if let title = annotation.title, title == "Your Location" {
                let annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "userLocation")
                annotationView.pinTintColor = .red // Use red pin for user's location
                annotationView.canShowCallout = true // Show callout for user location
                return annotationView
            }

            if annotation.title == "Villa Doria d'Angri" {
                // Customize Villa Doria annotation
                let annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "villaLocation")
                annotationView.markerTintColor = .red
                annotationView.glyphText = "🏛" // Use a building emoji for Villa Doria
                annotationView.canShowCallout = true
                return annotationView
            }

            // Default annotation view for other drop-off points (Green marker)
            let annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "batteryDropOff")
            annotationView.markerTintColor = .green
            annotationView.canShowCallout = true
            annotationView.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            return annotationView
        }

        // Action when a callout button is tapped
        func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
            guard let annotation = view.annotation else { return }

            let locationCoordinate = annotation.coordinate
            let mapItem = MKMapItem(placemark: MKPlacemark(coordinate: locationCoordinate))
            mapItem.name = annotation.title ?? "Destination"

            // Show action sheet to select Apple Maps or Google Maps
            let alert = UIAlertController(title: "Open in Maps", message: "Select your preferred map", preferredStyle: .actionSheet)

            alert.addAction(UIAlertAction(title: "Apple Maps", style: .default, handler: { _ in
                // Open in Apple Maps
                mapItem.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeWalking])
            }))

            alert.addAction(UIAlertAction(title: "Google Maps", style: .default, handler: { _ in
                // Open in Google Maps
                if let url = URL(string: "comgooglemaps://?daddr=\(locationCoordinate.latitude),\(locationCoordinate.longitude)&directionsmode=walking"),
                   UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                } else {
                    // Fallback to Google Maps website if the app isn't installed
                    if let url = URL(string: "https://www.google.com/maps/dir/?api=1&destination=\(locationCoordinate.latitude),\(locationCoordinate.longitude)&travelmode=walking") {
                        UIApplication.shared.open(url)
                    }
                }
            }))

            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))

            // Present the alert
            UIApplication.shared.windows.first?.rootViewController?.present(alert, animated: true, completion: nil)
        }

        // Render overlays (for the blue circle of user location)
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let circle = overlay as? MKCircle {
                let circleRenderer = MKCircleRenderer(overlay: circle)
                circleRenderer.fillColor = UIColor.blue.withAlphaComponent(0.2) // Blue circle with some transparency
                circleRenderer.strokeColor = UIColor.blue
                circleRenderer.lineWidth = 2
                return circleRenderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }
}

