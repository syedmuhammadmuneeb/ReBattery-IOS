import SwiftUI

struct HomeView: View {
    @Binding var points: Int  // Accept points as a binding
    @Binding var recycledItemsCount: Int  // Accept recycled items count as a binding
    @State private var showPopover = false  // State to control popover visibility
    
    let gridItems = [GridItem(.flexible()), GridItem(.flexible())]  // Two-column grid layout
    let themeColor = Color(hexCode: "#61BFAD")  // The hex theme color
    
    // This will track if the app is opened for the first time in the current session
    @AppStorage("hasOpenedThisSession") private var hasOpenedThisSession: Bool = false
    
    var body: some View {
        VStack(spacing: 20) {
            Spacer()  // To push content to the center of the screen
            
            // Points and Items Recycled Grid
            LazyVGrid(columns: gridItems, spacing: 20) {
                
                // Points Section
                VStack {
                    Text("My Points")
                        .font(.custom("Phosphate", size: 18))  // Reduced font size for the title
                        .foregroundColor(.white)
                        .bold()  // Bold text for better emphasis
                        .frame(maxWidth: .infinity)  // Make sure the title takes up full width for centering
                        .padding(.bottom, 6)  // Added bottom padding to give space between title and number
                    
                    Text("\(points)")
                        .font(.custom("Phosphate", size: 36))  // Reduced font size for points number
                        .foregroundColor(.white)
                        .bold()  // Bold points number for emphasis
                        .frame(width: 100, height: 100)  // Reduced circle size
                        .background(
                            Circle()
                                .fill(themeColor)
                                .shadow(radius: 5)
                        )
                        .padding(.top, 10)  // Adjusted spacing between circle and title
                }
                .padding(15)  // Padding around the entire section
                .frame(maxWidth: .infinity, maxHeight: 200)  // Ensure equal size box
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(themeColor.opacity(0.8))  // Using the theme color with opacity
                        .shadow(radius: 10)
                )
                
                // Items Recycled Section
                VStack {
                    Text("Items Recycled")
                        .font(.custom("Phosphate", size: 18))  // Reduced font size for the title
                        .foregroundColor(.white)
                        .bold()  // Bold text for better emphasis
                        .frame(maxWidth: .infinity)  // Make sure the title takes up full width for centering
                        .padding(.bottom, 6)  // Added bottom padding to give space between title and number
                    
                    Text("\(recycledItemsCount)")  // Display the dynamic count
                        .font(.custom("Phosphate", size: 36))  // Reduced font size for recycled items count
                        .foregroundColor(.white)
                        .bold()  // Bold recycled items count for emphasis
                        .frame(width: 100, height: 100)  // Equal circle size, reduced to fit better
                        .background(
                            Circle()
                                .fill(themeColor)
                                .shadow(radius: 5)
                        )
                        .padding(.top, 10)  // Adjusted spacing between circle and title
                }
                .padding(15)  // Padding around the entire section
                .frame(maxWidth: .infinity, maxHeight: 200)  // Ensure equal size box
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(themeColor.opacity(0.8))  // Using the theme color with opacity
                        .shadow(radius: 10)
                )
            }
            .padding(.horizontal, 10)  // Padding around the grid to prevent clipping

            Spacer()  // Add space between sections

            // "Earn Points" button
            Button(action: {
                showPopover.toggle()  // Toggle popover visibility when clicked
            }) {
                VStack {
                    Text("Earn Points by Recycling Batteries")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)  // Text color adapts to system mode
                    
                    Text("Get started →")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(themeColor)  // Set arrow color to the theme color
                }
                .frame(maxWidth: .infinity)  // Make the button wide to avoid text cutoff
            }
            .padding()
            .background(Color(.systemBackground))  // Ensure the background adapts to system mode
            .cornerRadius(8)  // Set corner radius but no outline
            .popover(isPresented: $showPopover) {
                VStack(alignment: .leading, spacing: 15) {
                    Text("Rules for Earning Points")
                        .font(.custom("Phosphate", size: 24))
                        .foregroundColor(themeColor)
                    
                    Text("1. Earn points for recycling batteries.")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)
                    
                    Text("2. The points are as under:")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)
                    
                    Text("   - 1 Mobile phone created: 5 points")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)
                    
                    Text("   - 1 Fork/Knife created: 3 points")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)
                    
                    Text("   - 1 Laptop created: 15 points")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)
                    
                    Text("   - 1 Watch created: 3 points")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)
                    
                    Text("   - 1 Screwdriver created: 4 points")
                        .font(.custom("Phosphate", size: 16))
                        .foregroundColor(.primary)
                    
                    Button(action: {
                        showPopover = false  // Close popover when button clicked
                    }) {
                        Text("Close")
                            .font(.custom("Phosphate", size: 16))
                            .foregroundColor(themeColor)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 8).stroke(Color.black, lineWidth: 1))
                    }
                    .padding(.top, 20)
                    Spacer()  // Add space at the bottom of the popover for better layout
                }
                .padding()
                .frame(width: 300, height: 350)  // Set a fixed size for the popover content
            }
        }
        .padding()
        .onAppear {
            // Only show popover if it's the first time this session
            if !hasOpenedThisSession {
                showPopover = true  // Show popover for first time
                hasOpenedThisSession = true  // Mark as opened
            }
        }
    }
}

