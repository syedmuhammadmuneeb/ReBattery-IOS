import SwiftUI
import MapKit // Add this import for MapKit types and functionalities

struct DashboardView: View {
    @State private var recycledItemsCount: Int = 0
    @State private var phoneAchieved: Bool = false
    @State private var forkKnifeAchieved: Bool = false
    @State private var laptopAchieved: Bool = false
    @State private var watchAchieved: Bool = false
    @State private var screwdriverAchieved: Bool = false
    
    @State private var phoneGalleryCount: Int = 0
    @State private var forkGalleryCount: Int = 0
    @State private var laptopGalleryCount: Int = 0
    @State private var watchGalleryCount: Int = 0
    @State private var screwdriverGalleryCount: Int = 0
    
    // Store drop-off points for uploading
    @State private var batteryDropOffPoints: [Location] = []
    
    var body: some View {
        VStack {
            Text("ReBattery")
                .font(.custom("Phosphate", size: 36))
                .foregroundColor(.white)
                .padding()
                .background(Color(hex: "#61BFAD"))

            Spacer()

            Text("My Points")
                .font(.custom("Phosphate", size: 24))
                .padding()

            Text("10")
                .font(.custom("Phosphate", size: 48))
                .bold()

            Text("Items Recycled")
                .font(.custom("Phosphate", size: 24))
                .padding()

            Text("\(recycledItemsCount)")
                .font(.custom("Phosphate", size: 48))
                .bold()

            Spacer()

            VStack {
                Text("Recycled Items Progress")
                    .font(.custom("Phosphate", size: 24))
                    .padding()

                HStack {
                    VStack {
                        Text("Phones")
                        Text("\(phoneGalleryCount) items")
                    }
                    VStack {
                        Text("Forks")
                        Text("\(forkGalleryCount) items")
                    }
                    VStack {
                        Text("Laptops")
                        Text("\(laptopGalleryCount) items")
                    }
                    VStack {
                        Text("Watches")
                        Text("\(watchGalleryCount) items")
                    }
                    VStack {
                        Text("Screwdrivers")
                        Text("\(screwdriverGalleryCount) items")
                    }
                }
            }

            Spacer()

            Button(action: {
                // Action for recycling batteries
            }) {
                Text("Earn Points by Recycling Batteries")
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()

            NavigationLink(destination: UploadView(
                recycledItemsCount: $recycledItemsCount,
                phoneAchieved: $phoneAchieved,
                forkKnifeAchieved: $forkKnifeAchieved,
                laptopAchieved: $laptopAchieved,
                watchAchieved: $watchAchieved,
                screwdriverAchieved: $screwdriverAchieved,
                phoneGalleryCount: $phoneGalleryCount,
                forkGalleryCount: $forkGalleryCount,
                laptopGalleryCount: $laptopGalleryCount,
                watchGalleryCount: $watchGalleryCount,
                screwdriverGalleryCount: $screwdriverGalleryCount,
                batteryDropOffPoints: batteryDropOffPoints // Pass drop-off points here
            )) {
                Text("Get started")
                    .padding()
                    .foregroundColor(.blue)
            }

            Spacer()
        }
        .onAppear {
            fetchBatteryDropOffPoints()
        }
    }
    
    // Fetch battery drop-off points
    private func fetchBatteryDropOffPoints() {
        // Define and search for the locations like in GoalsView
        let queries = ["Tabacchi", "Farmacia"]
        let villaDoriaLocation = Location(
            name: "Villa Doria d'Angri",
            coordinate: CLLocationCoordinate2D(latitude: 40.822975, longitude: 14.216369)
        )

        for query in queries {
            let request = MKLocalSearch.Request()
            request.naturalLanguageQuery = query
            request.region = MKCoordinateRegion(
                center: villaDoriaLocation.coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
            )

            let search = MKLocalSearch(request: request)
            search.start { response, error in
                if let error = error {
                    print("Error searching for \(query): \(error.localizedDescription)")
                    return
                }

                guard let response = response else { return }
                let locations = response.mapItems.prefix(5).map { item in
                    Location(name: "\(query): \(item.name ?? "Unknown")", coordinate: item.placemark.coordinate)
                }

                DispatchQueue.main.async {
                    self.batteryDropOffPoints.append(contentsOf: locations)
                }
            }
        }
    }
}

