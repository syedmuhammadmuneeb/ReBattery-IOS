import SwiftUI
import MapKit

struct ContentView: View {
    @State private var points: Int = 10  // Example points value
    @State private var recycledItemsCount: Int = 0  // Track total items recycled

    // Declare necessary state variables
    @State private var phoneAchieved: Bool = false
    @State private var forkKnifeAchieved: Bool = false
    @State private var laptopAchieved: Bool = false
    @State private var watchAchieved: Bool = false
    @State private var screwdriverAchieved: Bool = false
    
    @State private var phoneGalleryCount: Int = 0
    @State private var forkGalleryCount: Int = 0
    @State private var laptopGalleryCount: Int = 0
    @State private var watchGalleryCount: Int = 0
    @State private var screwdriverGalleryCount: Int = 0
    
    @State private var batteryDropOffPoints: [Location] = [] // Add this to hold the drop-off points

    var body: some View {
        NavigationView {
            TabView {
                // Pass both points and recycledItemsCount as bindings to HomeView
                HomeView(points: $points, recycledItemsCount: $recycledItemsCount)
                    .tabItem {
                        Image(systemName: "square")
                        Text("Dashboard")
                    }
                
                GoalsView()
                    .tabItem {
                        Image(systemName: "map")
                        Text("Map")
                    }
                
                // Pass the recycledItemsCount and drop-off points to UploadView
                UploadView(
                    recycledItemsCount: $recycledItemsCount,
                    phoneAchieved: $phoneAchieved,
                    forkKnifeAchieved: $forkKnifeAchieved,
                    laptopAchieved: $laptopAchieved,
                    watchAchieved: $watchAchieved,
                    screwdriverAchieved: $screwdriverAchieved,
                    phoneGalleryCount: $phoneGalleryCount,
                    forkGalleryCount: $forkGalleryCount,
                    laptopGalleryCount: $laptopGalleryCount,
                    watchGalleryCount: $watchGalleryCount,
                    screwdriverGalleryCount: $screwdriverGalleryCount,
                    batteryDropOffPoints: batteryDropOffPoints // Pass drop-off points here
                )
                .tabItem {
                    Image(systemName: "camera.fill")
                    Text("Upload")
                }
                
                // Pass both points and recycledItemsCount to MyCollectionsView
                MyCollectionsView(
                    points: $points,
                    totalItemsRecycled: $recycledItemsCount
                )
                .tabItem {
                    Image(systemName: "tray.full")
                    Text("My Collections")
                }
            }
            .accentColor(Color(hexCode: "#61BFAD"))
            .navigationBarTitleDisplayMode(.inline)  // Inline title
            .navigationTitle("ReBattery")  // Set the header for the content screen
            .onAppear {
                fetchBatteryDropOffPoints() // Fetch drop-off points when view appears
                setupNavigationBarAppearance()
            }
        }
    }

    // Function to set up navigation bar appearance
    private func setupNavigationBarAppearance() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(Color(hexCode: "#61BFAD"))
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().compactAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }

    // Function to fetch battery drop-off points (similar to GoalsView)
    private func fetchBatteryDropOffPoints() {
        let queries = ["Tabacchi", "Farmacia"]
        let villaDoriaLocation = CLLocationCoordinate2D(latitude: 40.822975, longitude: 14.216369)

        for query in queries {
            let request = MKLocalSearch.Request()
            request.naturalLanguageQuery = query
            request.region = MKCoordinateRegion(
                center: villaDoriaLocation,
                span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
            )

            let search = MKLocalSearch(request: request)
            search.start { response, error in
                if let error = error {
                    print("Error searching for \(query): \(error.localizedDescription)")
                    return
                }

                guard let response = response else { return }
                let locations = response.mapItems.prefix(5).map { item in
                    Location(name: "\(query): \(item.name ?? "Unknown")", coordinate: item.placemark.coordinate)
                }

                DispatchQueue.main.async {
                    self.batteryDropOffPoints.append(contentsOf: locations)
                }
            }
        }
    }
}

